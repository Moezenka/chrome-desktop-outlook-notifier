# chrome-desktop-outlook-notifier
A Chrome/Brave/Edge extension for Outlook 365 Desktop notifications for meetings

To install this chrome extension:

1. Download the repo content as zip, using this link https://github.com/tbeadle/chrome-desktop-outlook-notifier/archive/master.zip
2. Unzip creating a folder
3. Go to Chrome Setup -> Extensions
4. Enable the option "Developer mode"
5. Use the "Load unpacked" option and select the folder you created before
6. Open or reload the Outlook Webapp tab and allow notifications if asked
7. Reload again if you were asked for allow notifications
8. Enjoy Outlook Desktop Reminders when using chrome/brave.
